import java.util.Scanner;
        public class CompoundProg {
            public static void main(String[] args) {
                
                int num, posta, prea, posts, pres;
                Scanner input = new Scanner(System.in);
                
                //user input a number
                System.out.println("Enter a number :");
                num = input.nextInt();
                
                //calculate increament and decreament between 4 operator
                posta = num;
                posta = (posta++);
                
                prea = num;
                prea = (++prea);
                
                pres = num;
                pres = (pres--);
                
                posts = num;
                posts = (--posts);
                
                //all output shown
                System.out.println("pre-addition :"+prea);
                System.out.println("pre-substraction :"+pres);
                System.out.println("post-addition :"+posta);
                System.out.println("post-subtraction :"+posts);
            }
        }
