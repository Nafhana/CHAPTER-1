import java.util.Scanner;
        public class UserInput {
            public static void main(String[] args) {
                
                String name, hobby, favfood;
                int age;
                Scanner input = new Scanner(System.in);
                
                //user input all information
                System.out.println("Enter your name :");
                name = input.nextLine();
                System.out.println("Enter your age :");
                age = input.nextInt();
                input.nextLine();
                System.out.println("Enter your hobby :");
                hobby = input.nextLine();
                System.out.println("Enter your favorite food :");
                favfood = input.nextLine();
                input.close();
                
                //user's information shown
                System.out.println("Name :"+name);
                System.out.println("Age :"+age);
                System.out.println("Hobby :"+hobby);
                System.out.println("Favorite Food :"+favfood);
            }
        }
