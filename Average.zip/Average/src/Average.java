import java.util.Scanner;
        public class Average {
            public static void main(String[] args) {
                
                int Test1, Test2;
                String name, ID, sub;
                float avg;
                Scanner input = new Scanner(System.in);
                
                //user enter all information about the test
                System.out.println("Enter your name :");
                name = input.nextLine();
                System.out.println("Enter your student ID :");
                ID = input.nextLine();
                System.out.println("Enter the subject :");
                sub = input.nextLine();
                System.out.println("Enter test1 mark(/100) :");
                Test1 = input.nextInt();
                System.out.println("Enter test2 mark(/100) :");
                Test2 = input.nextInt();
                
                //calcuate average mark of both test
                avg = (Test1 + Test2) / 2;
                
                //user information and test average shown
                System.out.println("Name :"+name);
                System.out.println("Student ID :"+ID);
                System.out.println("Subject :"+sub);
                System.out.println("Your average mark is :"+avg);
            }
        }