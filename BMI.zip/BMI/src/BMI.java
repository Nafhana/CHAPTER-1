import java.util.Scanner;
        public class BMI {
            public static void main(String[] args) {
                
                float height, weight, bmi;
                Scanner input = new Scanner(System.in);
                
                //user enter their haight and weight
                System.out.println("Enter your height(m) :");
                height = input.nextFloat();
                System.out.println("Enter your weight(KG) :");
                weight = input.nextFloat();
                
                //calculate user's BMI
                bmi = weight / (height * height);               
                
                //user's BMI shown
                System.out.println("BMI :"+bmi);
            }
        }
