import java.util.Scanner;
        public class Discount {
            public static void main(String[] args) {
                
                String itemName;
                int quantity;
                float price, discountRate, totalPrice, after, discount;
                Scanner input = new Scanner(System.in);
                
                //user enter item's information
                System.out.println("Enter the name of the item :");
                itemName = input.nextLine();
                System.out.println("Enter the price :");
                price = input.nextFloat();
                System.out.println("Enter the item quantity :");
                quantity = input.nextInt();
                System.out.println("Enter the discount rate :");
                discountRate = input.nextFloat();
                
                //calculate total price and the price after discount
                totalPrice = price * quantity;
                discount = (discountRate / 100) * totalPrice;
                after = totalPrice - discount;
                
                //item's information and both before and after discount price shown
                System.out.println("Item name :"+itemName);
                System.out.println("Item price :"+price);
                System.out.println("Item quantity :"+quantity);
                System.out.println("Total Price :"+totalPrice);
                System.out.println("Discount rate :"+discountRate);
                System.out.println("Item price after discount :"+after);
            }
        }
