import java.util.Scanner;
        public class CalcAge {
            public static void main(String[] args) {
                
                int age, birth, current;
                Scanner input = new Scanner(System.in);
                
                //user input their birthyear and the current year
                System.out.println("Enter your birthyear :");
                birth = input.nextInt();
                System.out.println("Enter the current year :");
                current = input.nextInt();
                
                //calculate user age
                age = current - birth;
                
                //user's age shown
                System.out.println("Age :"+age);
            }
        }

