import java.util.Scanner;
        public class ArithmeticProg {
            public static void main(String[] args) {
                
                int num1, num2;
                float divid, add, subs, mult, mod, increament1, increament2, decreament1, decreament2;
                Scanner input = new Scanner(System.in);
                
                //make user input both numbers
                System.out.println("Enter first number :");
                num1 = input.nextInt();
                System.out.println("Enter second number :");
                num2 = input.nextInt();
                
                //arithmetic calculation
                add = num1 + num2;
                subs = num1 - num2;
                mult = num1 * num2;
                mod = num1 % num2;
                divid = num1 / num2;
                increament1 = ++num1;
                decreament2 = --num2;
                
                //output shown
                System.out.println("Addition :"+add);
                System.out.println("Substraction :"+subs);
                System.out.println("Multiplication :"+mult);
                System.out.println("Modulus :"+mod);
                System.out.println("Division :"+divid);
                System.out.println("First number increament :"+increament1);
                System.out.println("Second number decreament :"+decreament2);  
            }}

